# job4j-design

[![Build Status](https://travis-ci.org/Haliz/job4j_design.svg?branch=master)](https://travis-ci.org/Haliz/job4j_design)

[![codecov](https://codecov.io/gh/Haliz/job4j_design/branch/master/graph/badge.svg?token=KT5R2WEDG9)](https://codecov.io/gh/Haliz/job4j_design)